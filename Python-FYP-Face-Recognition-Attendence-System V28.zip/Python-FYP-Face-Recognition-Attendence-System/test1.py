import tkinter as tk
from tkinter import messagebox
import mysql.connector
from passlib.hash import pbkdf2_sha256  # Install passlib using: pip install passlib

# Function to hash the password using pbkdf2_sha256
def hash_password(password):
    return pbkdf2_sha256.hash(password)

# Function to verify hashed password
def verify_password(password, hashed_password):
    return pbkdf2_sha256.verify(password, hashed_password)

# Function to handle login button click
def login():
    username = entry_username.get()
    password = entry_password.get()

    try:
        # Connect to MySQL database
        conn = mysql.connector.connect(
            host="your_mysql_host",
            user="your_mysql_user",
            password="your_mysql_password",
            database="your_mysql_database"
        )

        cursor = conn.cursor()

        # Retrieve hashed password from the database based on the username
        cursor.execute("SELECT password FROM regteach WHERE Email=%s", (username,))
        result = cursor.fetchone()

        if result:
            hashed_password = result[0]

            # Verify the entered password with the hashed password
            if verify_password(password, hashed_password):
                messagebox.showinfo("Login", "Login successful")
            else:
                messagebox.showerror("Login", "Invalid password")
        else:
            messagebox.showerror("Login", "User not found")

    except mysql.connector.Error as err:
        messagebox.showerror("Error", f"MySQL Error: {err}")

    finally:
        cursor.close()
        conn.close()

# Create the main window
root = tk.Tk()
root.title("Login Form")

# Create and place widgets in the window
label_username = tk.Label(root, text="Username:")
label_username.pack()

entry_username = tk.Entry(root)
entry_username.pack()

label_password = tk.Label(root, text="Password:")
label_password.pack()

entry_password = tk.Entry(root, show="*")
entry_password.pack()

btn_login = tk.Button(root, text="Login", command=login)
btn_login.pack()

# Run the Tkinter event loop
root.mainloop()
